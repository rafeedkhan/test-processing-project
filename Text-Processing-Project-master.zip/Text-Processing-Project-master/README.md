In the name of Allah most gracious and most merciful.
# Text-Processing-Project
